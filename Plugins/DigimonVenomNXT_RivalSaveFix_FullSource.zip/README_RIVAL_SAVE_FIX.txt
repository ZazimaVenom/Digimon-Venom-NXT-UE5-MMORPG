DIGIMON VENOM NXT — BOUNDED PERSISTENT RIVALS
Source update for the supplied Source(2).rar baseline
27 October 2026

INSTALL AND COMPACT YOUR EXISTING SAVE

1. Close the host/game and Unreal Editor. Keep an external copy of your current
   Saved/DigimonVenomNXT folder before the first upgraded launch. Cleanup releases
   surplus BOT Digimon; that release becomes permanent when you save.
2. Replace your DigimonVenomNXT plugin's Source folder with this archive's complete
   Source folder. Keep your existing .uplugin, Content, Resources and other plugin
   files. The supplied baseline contained source only; this update is source only.
3. Rebuild your Unreal project/plugin normally, including the editor target. If
   stale plugin binaries interfere, remove only that plugin's Binaries/Intermediate
   folders while Unreal is closed, then rebuild. Do not remove Saved or Content.
4. Start the host's public game world with the existing AIRivals.json in place.
   Loading now streams and compacts one rival at a time. You do not need to delete
   AIRivals.json or reset the rival population.
5. Run /saveall from the authenticated host console. With autosaving disabled,
   this first successful manual save is what replaces the old large file on disk.
   Check the log for 'Rival retention:' and 'Saved ... persistent rivals in ... MiB'.
6. Restart the host and verify retained bot parties/progression load correctly.

WHAT CHANGED

- New default ownership capacity: 24 Digimon per rival, INCLUDING the active party.
- Absolute per-rival ownership ceiling: 64. Old INI values such as 1536 cannot bypass
  runtime limits. An existing 1536 setting therefore becomes at most 64, not 24;
  set AIRivalMaxCollectionSize=24 to choose the new default explicitly.
- A shared 64,000-owned-creature budget scales each rival's limit downward for large
  populations. Stored paused rivals count too. With 5000 stored/configured rivals,
  each bot can retain 12 Digimon. Configured active parties up to 12 always fit.
- Materialization checks capacity before allocating a new Digimon or spending scan
  progress. Full bots continue training, evolving and battling their existing
  roster. They cannot bypass capacity by evolving away from an earlier species.
- Legacy over-capacity ownership is released deterministically. Current valid
  active party copies win over stale stored copies. Retention next prioritizes
  the training leader, original first companion, then reserves by ABI, permanent
  training, level, XP, CAM and variant. Party members take priority if every slot
  is needed for the active party. Remaining ties preserve prior order.
- Released/invalid/duplicate owned records and orphan training histories are
  removed, not copied into an ever-growing retirement archive. Kept creatures
  retain GUID, species, variant, progression, training, vitality and equipped IDs.
- Scan storage defaults 128, has an absolute 256 limit, and shares a 128,000-record
  population budget. At 1000 rivals the effective maximum is 128; at 5000 it is 25.
  Duplicate/invalid/spent scans are removed; usable progress is prioritized.
  Bot discovery history for discarded scans is intentionally not an archive.
- Empty/duplicate inventory records and redundant catalog move text are cleaned.
  Checkpoints store equipped move IDs; combat reconstructs their catalog metadata.
- Cleanup runs on load, at simulation boundaries, after party synchronization and
  before saving. Disabling autosaves cannot disable memory/storage limits.
- Lifetime aggregate activity totals remain; human account/collection data is not
  processed by rival cleanup. Autosave preferences and /saveall access are unchanged.

SAVING AND RECOVERY

The previous writer created the whole population's JSON object tree and a huge
string at once. The new writer serializes condensed UTF-8 one rival at a time.
A hard 256 MiB file ceiling rejects an abnormal oversized checkpoint while retaining
existing complete saves. Normal population/collection/scan limits are much smaller.
This is a safety guard, not a guarantee about every possible source of game crashes.

The loader validates/indexes legacy JSON without a whole-file string or DOM, then
loads and compacts each rival before moving to the next. Schema 3 and older compatible
saves remain accepted. Newer schemas, malformed/truncated JSON, duplicate rival IDs,
more than 5000 rival records, files above 8 GiB, or an individual legacy rival above 64 MiB
are rejected without overwriting the source. A bad primary can recover from .bak;
if neither file is valid, rival simulation is disabled rather than resetting it.
Missing species data also disables startup cleanup to protect saves.

Temporary files are closed before atomic replacement. One .bak is rotated through
its own temporary file. When replacing an oversized legacy primary or recovering
from backup, the backup is seeded from the completed compact checkpoint rather than
retaining another giant copy. Oversized old .corrupt diagnostic files are removed
only after valid primary and backup checkpoints exist. No dated archive accumulation
is introduced. Keep your separate pre-upgrade copy if you want the original roster.

SETTINGS AND RELEASE API

Project Settings > Digimon Venom NXT > AI Rivals:
  AIRivalMaxCollectionSize =24 (runtime 6..64, party/population rules also apply)
  AIRivalMaxScanRecords =128 (runtime 16..256, population rules also apply)

For server-side gameplay/Blueprint administration, ReleaseStoredPartner(RivalId,
InstanceId) releases a reserve and immediately removes its ownership/history.
It refuses client calls, active party members, the current training leader, unknown
GUIDs, and rivals in live battles. It opens a slot without creating any replacement;
the normal simulation may materialize later. The operation follows existing save
preferences: /saveall persists it when automatic saving is disabled. Bots do not
randomly delete their current roster merely to keep materializing forever.

VALIDATION AND LIMITATIONS

Executed in the supplied workspace:
- Production capacity rules:480,000 population/party/config combinations passed.
- Production streaming scanner/byte-budget rules:126 checks passed, including a
  generated 1,073,761,310-byte stream with 1024 indexed records, malformed/truncated
  JSON, nesting/Unicode/schema/population/record limits and byte-budget overflow.
- AddressSanitizer/UndefinedBehaviorSanitizer:124 non-stress scanner checks passed
  with leak detection disabled because process inspection is restricted here.
- Source whitespace/diff checks passed; every original source file is included.

Run the portable checks from the archive root on Linux/macOS/WSL with a C++17 compiler:
  bash validation/run_regressions.sh

Eight Unreal automation scenarios are included under:
  DigimonVenomNXT.Rivals.Retention
  DigimonVenomNXT.Rivals.Persistence
They cover legacy pruning, active-party preservation, release/history removal,
scan/inventory cleanup, large-population limits,20160 full-capacity materialization
attempts, compact/legacy JSON round trips and failed-load/write preservation.

Unreal Engine and the live 1 GB AIRivals.json were not supplied in this environment.
The Unreal module, engine automation scenarios, real-save migration and in-game
/saveall still require verification in your rebuilt project. The portable 1 GB test
exercises the streaming scanner; it is not a claimed full Unreal game/load test.
