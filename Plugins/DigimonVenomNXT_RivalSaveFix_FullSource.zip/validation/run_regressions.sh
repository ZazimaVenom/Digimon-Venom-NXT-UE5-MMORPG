#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
build_dir="$(mktemp -d /tmp/dvnxt-rival-regressions.XXXXXX)"
trap 'rm -rf -- "$build_dir"' EXIT
"${CXX:-c++}" -std=c++17 -Wall -Wextra -Werror -pedantic -O2 -I Source/DigimonVenomNXTRuntime/Public validation/rival_retention_limits.cpp -o "$build_dir/retention"
"$build_dir/retention"
"${CXX:-c++}" -std=c++17 -Wall -Wextra -Werror -pedantic -O2 validation/rival_persistence_core.cpp -o "$build_dir/persistence"
"$build_dir/persistence" --gigabyte
