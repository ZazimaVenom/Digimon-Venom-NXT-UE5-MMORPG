#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
binary="$(mktemp /tmp/dvnxt-rival-persistence.XXXXXX)"
trap 'rm -f -- "$binary"' EXIT
"${CXX:-c++}" -std=c++17 -Wall -Wextra -Werror -O2 validation/rival_persistence_core.cpp -o "$binary"
"$binary" --gigabyte
