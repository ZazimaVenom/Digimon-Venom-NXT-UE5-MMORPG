#include "DigimonVenomNXTRivalRetentionCore.h"
#include <cassert>
#include <climits>
#include <iostream>
int main()
{
    using namespace DigimonVenomNXTRivalRetentionCore;
    assert(CollectionLimit(1536)==64);
    assert(CollectionLimit(24)==24);
    assert(CollectionLimit(INT_MIN,12)==12);
    assert(CollectionLimit(INT_MAX,6,5000)==12);
    assert(ScanLimit(INT_MAX,5000)==25);
    assert(ScanLimit(INT_MAX,1)==256);
    assert(ScanLimit(INT_MAX,1000)==128);
    int Cases=0;
    for(int Population=1;Population<=5000;++Population)
        for(int Party=1;Party<=12;++Party)
            for(int Config : {INT_MIN,0,6,12,24,64,1536,INT_MAX})
            {
                const int Limit=CollectionLimit(Config,Party,Population);
                const int Scans=ScanLimit(Config,Population);
                assert(Limit>=Party && Limit>=6 && Limit<=64);
                assert(Limit*Population<=GlobalOwnedBudget);
                assert(Scans>=16 && Scans<=256);
                assert(Scans*Population<=GlobalScanBudget);
                assert(CollectionLimit(Limit,Party,Population)==Limit);
                assert(ScanLimit(Scans,Population)==Scans);
                ++Cases;
            }
    std::cout << Cases << " population/party/config combinations passed\n";
}
