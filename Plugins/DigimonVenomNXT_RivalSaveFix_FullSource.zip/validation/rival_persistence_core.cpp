#include "../Source/DigimonVenomNXTRuntime/Public/DigimonVenomNXTRivalJsonStreamCore.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace DigimonVenomNXTRivalJsonStreamCore;

struct StringInput
{
    const std::string& Text;
    std::size_t Cursor = 0;
    bool bFailure = false;
    int Peek() const { return Cursor < Text.size() ? static_cast<unsigned char>(Text[Cursor]) : -1; }
    int Get() { const int C = Peek(); if (C >= 0) ++Cursor; return C; }
    std::int64_t Position() const { return static_cast<std::int64_t>(Cursor); }
    bool Failed() const { return bFailure; }
};

// Generates an arbitrarily large legacy JSON stream without storing it in RAM.
struct GeneratedInput
{
    const std::string Prefix = "{\"schemaVersion\":3,\"rivals\":[";
    const std::string RecordStart = "{\"displayName\":\"";
    const std::string RecordEnd = "\"}";
    const std::string Suffix = "]}";
    std::int64_t Payload, Count, Cursor = 0;
    GeneratedInput(std::int64_t InPayload, std::int64_t InCount) : Payload(InPayload), Count(InCount) {}
    std::int64_t RowSize() const { return RecordStart.size() + Payload + RecordEnd.size() + 1; }
    std::int64_t RecordsSize() const { return RowSize() * Count - 1; }
    int Peek() const
    {
        auto P = Cursor;
        if (P < static_cast<std::int64_t>(Prefix.size())) return Prefix[static_cast<std::size_t>(P)];
        P -= Prefix.size();
        if (P < RecordsSize())
        {
            P %= RowSize();
            if (P < static_cast<std::int64_t>(RecordStart.size())) return RecordStart[static_cast<std::size_t>(P)];
            P -= RecordStart.size();
            if (P < Payload) return 'x';
            P -= Payload;
            if (P < static_cast<std::int64_t>(RecordEnd.size())) return RecordEnd[static_cast<std::size_t>(P)];
            return ',';
        }
        P -= RecordsSize();
        return P < static_cast<std::int64_t>(Suffix.size()) ? Suffix[static_cast<std::size_t>(P)] : -1;
    }
    int Get() { const int C = Peek(); if (C >= 0) ++Cursor; return C; }
    std::int64_t Position() const { return Cursor; }
    bool Failed() const { return false; }
};

static int Checks = 0;
static void Check(bool Passed, const std::string& Name)
{
    ++Checks;
    if (!Passed) { std::cerr << "FAIL: " << Name << '\n'; std::exit(1); }
}
static Index Scan(const std::string& Text, bool Expected)
{
    StringInput Input{Text};
    Index Result;
    Check(Scanner<StringInput>(Input, Result).Run() == Expected, Text.substr(0, 100));
    return Result;
}
int main(int Argc, char** Argv)
{
    std::int64_t Budget = 0;
    Check(AdvanceCheckpointBudget(MaxCheckpointBytes - 2, Budget), "Write below byte ceiling");
    Check(AdvanceCheckpointBudget(2, Budget) && Budget == MaxCheckpointBytes, "Exact byte ceiling accepted");
    Check(!AdvanceCheckpointBudget(1, Budget) && Budget == MaxCheckpointBytes, "One extra byte rejected without changing count");
    Check(!AdvanceCheckpointBudget(std::numeric_limits<std::int64_t>::max(), Budget), "Overflow-sized write rejected");
    Check(!AdvanceCheckpointBudget(-1, Budget), "Negative write rejected");
    auto Empty = Scan("{\"rivals\":[]}", true);
    Check(Empty.SchemaVersion == 3 && Empty.Records.empty(), "Legacy default schema");
    const std::string First = "{\"rivalId\":\"AI-0001\",\"text\":\"a } \\\" [ \\\\ z\",\"nested\":[false,null,1.2e-2,{\"s\":true}]}";
    const std::string Second = "{\"rivalId\":\"AI-0002\",\"text\":\"\\ud83d\\ude00\"}";
    const std::string Full = "\xef\xbb\xbf{\"unknown\":{\"array\":[1,2]},\"Rivals\":[" + First + "," + Second + "],\"SchemaVersion\":3,\"LastSavedUnix\":9223372036854775807,\"ActivityWindowStartUnix\":-9223372036854775808}";
    auto Indexed = Scan(Full, true);
    Check(Indexed.Records.size() == 2, "Both records indexed");
    Check(Full.substr(Indexed.Records[0].Offset, Indexed.Records[0].Length) == First, "First record boundary excludes braces in strings");
    Check(Full.substr(Indexed.Records[1].Offset, Indexed.Records[1].Length) == Second, "Second record exact UTF-8 byte range");
    Check(Indexed.LastSavedUnix == std::numeric_limits<std::int64_t>::max(), "Maximum signed metadata");
    Check(Indexed.ActivityWindowStartUnix == std::numeric_limits<std::int64_t>::min(), "Minimum signed metadata");
    Scan("{\"rivals\":[],\"escaped\":\"\xc3\xa9\xf0\x9f\x98\x80\"}", true);
    Scan("{\"\\u0072ivals\":[]}", true);
    const std::vector<std::string> Invalid = {
        "", "[]", "{}", "{\"rivals\":{}}", "{\"rivals\":[null]}", "{\"rivals\":[{},]}",
        "{\"rivals\":[],}", "{\"rivals\":[]}trailing", "{\"rivals\":[],\"Rivals\":[]}",
        "{\"rivals\":[],\"schemaVersion\":3,\"SchemaVersion\":3}",
        "{\"rivals\":[],\"activityWindowStartUnix\":1,\"ActivityWindowStartUnix\":1}",
        "{\"rivals\":[],\"lastSavedUnix\":1,\"LastSavedUnix\":1}",
        "{\"rivals\":[],\"schemaVersion\":-1}", "{\"rivals\":[],\"schemaVersion\":3.0}",
        "{\"rivals\":[],\"lastSavedUnix\":01}", "{\"rivals\":[],\"lastSavedUnix\":1e3}",
        "{\"rivals\":[],\"lastSavedUnix\":9223372036854775808}",
        "{\"rivals\":[],\"lastSavedUnix\":-9223372036854775809}",
        "{\"rivals\":[{\"s\":\"\\ud800\"}]}", "{\"rivals\":[{\"s\":\"\\udc00\"}]}",
        "{\"rivals\":[{\"s\":\"\\u12xz\"}]}", "{\"rivals\":[{\"s\":\"\\v\"}]}",
        "{\"rivals\":[{\"s\":\"\xc0\x80\"}]}", "{\"rivals\":[{\"s\":\"\xed\xa0\x80\"}]}",
        "{\"rivals\":[{\"s\":\"\xf4\x90\x80\x80\"}]}", "{\"rivals\":[{\"s\":\"\n\"}]}",
        "{\"rivals\":[{\"n\":01}]}", "{\"rivals\":[{\"n\":1.}]}", "{\"rivals\":[{\"n\":1e}]}",
        "{\"rivals\":[{\"n\":+1}]}", "{\"rivals\":[{\"n\":NaN}]}", "{\"rivals\":[{\"b\":True}]}",
        "{\"rivals\":[{\"n\":false false}]}"
    };
    for (const auto& Bad : Invalid) Scan(Bad, false);
    Check(Scan("{\"rivals\":[{}],\"schemaVersion\":4}", false).UnsupportedSchema, "Newer schema after records rejected before decode");
    Check(Scan("{\"schemaVersion\":4,\"rivals\":[{}]}", false).UnsupportedSchema, "Newer schema first rejected");
    const std::string Valid = "{\"rivals\":[{\"s\":\"escaped \\\" braces {}\",\"a\":[0,false]}]}";
    for (std::size_t I = 0; I < Valid.size(); ++I) Scan(Valid.substr(0, I), false);
    Scan(Valid, true);
    for (int Boundary = 0; Boundary < 12; ++Boundary)
    {
        const std::string Across = "{\"rivals\":[{\"s\":\"" + std::string(65536 - Boundary, 'x') + "\\ud83d\\ude00 } [ \\\"\"}]}";
        Scan(Across, true);
    }
    Scan("{\"rivals\":[{\"v\":" + std::string(65, '[') + "0" + std::string(65, ']') + "}]}", false);
    StringInput Failed{"{\"rivals\":[]}", 0, true};
    Index FailedIndex;
    Check(!Scanner<StringInput>(Failed, FailedIndex).Run(), "Input failure rejects valid-looking prefix");
    GeneratedInput TooMany{0, 5001};
    Index TooManyIndex;
    Check(!Scanner<GeneratedInput>(TooMany, TooManyIndex).Run(), "Population >5000 rejected without truncating");
    GeneratedInput TooBig{MaxLegacyRecordBytes, 1};
    Index TooBigIndex;
    Check(!Scanner<GeneratedInput>(TooBig, TooBigIndex).Run(), "Individual legacy record >64MiB rejected");
    if (Argc > 1 && std::string(Argv[1]) == "--gigabyte")
    {
        GeneratedInput Large{1024LL * 1024, 1024};
        Index LargeIndex;
        Check(Scanner<GeneratedInput>(Large, LargeIndex).Run(), "Stream >1GiB without constructing it");
        Check(LargeIndex.Records.size() == 1024, "Every generated legacy record is indexed");
        std::cout << "Indexed " << Large.Position() << " bytes with " << LargeIndex.Records.size() << " ranges.\n";
    }
    std::cout << Checks << " persistence scanner checks passed.\n";
}
